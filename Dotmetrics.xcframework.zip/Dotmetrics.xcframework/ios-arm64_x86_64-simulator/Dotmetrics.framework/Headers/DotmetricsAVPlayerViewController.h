//
//  DotmetricsAVPlayerViewController.h
//  Dotmetrics
//
//  Created by Denis Jakuš on 21.01.2022..
//  Copyright © 2022 Telekomunikacijske Usluge. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVKit/AVKit.h>

@interface DotmetricsAVPlayerViewController: AVPlayerViewController

@end
